# Zumba
Project for Managing Zumba Schedules based on Servlet and JSPs.
